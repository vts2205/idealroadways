<?php return array (
  'state-district' => 'App\\Http\\Livewire\\StateDistrict',
);