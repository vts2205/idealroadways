
<?php $__env->startSection('title','Master Admin | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper ">

    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="float-right page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><?php echo e(env('APP_NAME')); ?></a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
                <h5 class="page-title">Dashboard</h5>
            </div>
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary  text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-cube-outline float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Branch</h6>
                    </div>
                    <div class="card-body">
                        <div class=" text-center ">
                            <h3>123</h3>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-account-network float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Transport</h6>
                    </div>
                  <div class="card-body">
                        <div class=" text-center ">
                            <h3>3</h3>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-tag-text-outline float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Truck</h6>
                    </div>
                 <div class="card-body">
                        <div class=" text-center ">
                            <h3>12</h3>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-cart-outline float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Loads</h6>
                    </div>
                  <div class="card-body">
                        <div class=" text-center ">
                            <h3>13</h3>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->


    </div><!-- container fluid -->

</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_admin.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\vts\ideal\resources\views/master_admin/dashboard.blade.php ENDPATH**/ ?>