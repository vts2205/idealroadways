
<?php $__env->startSection('title','  Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper ">

    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="float-right page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><?php echo e(env('APP_NAME')); ?></a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
                <h5 class="page-title">Dashboard</h5>
            </div>
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary  text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-cube-outline float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Branch</h6>
                    </div>
                    <div class="card-body">
                        <div class=" text-center ">
                            <h3><?php echo e($record['branch']); ?></h3>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-account-network float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Transport</h6>
                    </div>
                  <div class="card-body">
                        <div class=" text-center ">
                            <h3><?php echo e($record['transport']); ?></h3>

                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-tag-text-outline float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Truck</h6>
                    </div>
                 <div class="card-body">
                        <div class=" text-center ">
                            <h3><?php echo e($record['truck']); ?></h3>

                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat m-b-30">
                    <div class="p-3 bg-primary text-white">
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-cart-outline float-right mb-0"></i>
                        </div>
                        <h6 class="text-uppercase mb-0">Total Loads</h6>
                    </div>
                  <div class="card-body">
                        <div class=" text-center ">
                            <h3><?php echo e($record['load']); ?></h3>

                        </div>
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="row" >
            <div class="col-12">
                <div class="card">
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        </form>
                    <div class="card-header">
                        <div class="float-right col-md-4">
                            <label>State</label>
                            <select class="form-control">
                                <option value="">All</option>
                                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->state); ?>"><?php echo e($state->state); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>  
                    </div>
                    <div class="card-body" id="map" style="height: 100vh;border:1px solid red  ">

                    </div>
                </div>
            </div>

        </div>
        <!-- end row -->


    </div><!-- container fluid -->

</div>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
 <script
      src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAP_API')); ?>&callback=initMap&libraries=&v=weekly"
      async
    ></script>

<script>
    let object=[];
let arr=[];

<?php
    foreach($trucks as $truck)
    {
        ?>
        var pos={ lat: '<?php echo e($truck["lat"]); ?>', lng:'<?php echo e($truck["lng"]); ?>' };
        var num='<?php echo e($truck["number"]); ?>'
         arr=[pos,num]
        object.push(arr)
        <?php 
    }
?>
    function initMap(center={ lat: 20.5937, lng: 78.9629 },zoom=8) {
    

  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: zoom,
    center: center,
  });
  for(var i=0;i<object.length;i++)
  {
    object[i][0]['lat']=parseInt(object[i][0]['lat'])
    object[i][0]['lng']=parseInt(object[i][0]['lng'])
    var marker = new google.maps.Marker({
        position: object[i][0],
        map,
        title: object[i][1],
    });
    
  }
}
$(document).ready(function() {
        $('select').select2();
    });

$(document).on('change','select',function(){
    var val=$(this).val();
    if(val=='all')
    {
        return false;
    }
    $.ajax({
        url:`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURI(val)}&key=<?php echo e(env('MAP_API')); ?>

            `,
        method:"POST",
        success:function(data){
            data=data['results'][0]['geometry']['location']
            initMap(data,zoom=8)
        }
    })
})
</script>
<?php echo $__env->make('pusher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master_admin.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\vts\ideal\resources\views/master_admin/dashboard.blade.php ENDPATH**/ ?>