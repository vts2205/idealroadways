<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Hash;	
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
class LoginController extends Controller
{
    public function View_Login()
    {
    // 	$user = new User;

	   // $user->name = 'Ideal Roadways';
	   // $user->username = 'Ideal';
	   // $user->role = 'master_admin';
	   // $user->password = Hash::make('Ideal12#');
	   // $user->user_id='-1';
	   // $user->save();
    	return view('login');

    }
    public function login(Request $request)
    {
    	 $request->validate([
		    'username' => ['required'],
		    'password' => ['required'],
		]);
    	 $credentials = $request->only('username', 'password');

        if (Auth::attempt($credentials)) {
            // print_r(Auth::user());
            if (Auth::user()->role == 'master_admin') {
                return redirect()->route('master_admin_dashboard');
            }
            if (Auth::user()->role == 'admin') {
                return redirect()->route('admin-dashboard');
            }
            if (Auth::user()->role == 'driver') {
                return redirect()->route('driver-dashboard');
            }
            if (Auth::user()->role == 'transport') {
                return redirect()->route('transport-dashboard');
            }
            if (Auth::user()->role == 'truck') {
                return redirect()->route('truck-dashboard');
            }
        }
        else
        {
            return redirect()->back()->withInput($request->only('username', 'password'))->withErrors([
                'login_error' => 'Username and password mismatched !',
            ]);
            // return back()->withErrors(['login_error', 'username and password mismatched!']);
        }
    	// dd($request->all());
    }
    public function logout()
    {
        Auth::logout();
        return redirect('/login');

    }
    public function home()
    {
            if (!Auth::check()) {
                return redirect()->route('login');
            }
            if (Auth::user()->role == 'master_admin') {
                return redirect()->route('master_admin_dashboard');
            }
            if (Auth::user()->role == 'admin') {
                return redirect()->route('admin-dashboard');
            }
            if (Auth::user()->role == 'driver') {
                return redirect()->route('driver-dashboard');
            }
            if (Auth::user()->role == 'transport') {
                return redirect()->route('transport-dashboard');
            }
    }
}
