
<?php $__env->startSection('title','Transport | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper ">

    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="float-right page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                    
<br>
                </div>
                <h5 class="page-title">Dashboard</h5>
            </div>
        </div>
        <!-- end row -->
<style type="text/css">
    #map {
  height: 100%;
}
</style>
        <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  My Trucks
                <div>

                <div class="card-body" id="map" style="height: 100vh;border:1px solid red  ">

                </div>
              </div>
            </div>
         </div>
         <form method="POST">
         <?php echo csrf_field(); ?>
         </form>
        <!-- end row -->


    </div><!-- container fluid -->

</div>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
 <script
      src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAP_API')); ?>&callback=initMap&libraries=&v=weekly"
      async
    ></script>

<script>
    let object=[];
let arr=[];

<?php
    foreach($trucks as $truck)
    {
        ?>
        var pos={ lat: '<?php echo e($truck["lat"]); ?>', lng:'<?php echo e($truck["lng"]); ?>' };
        var num='<?php echo e($truck["number"]); ?>'
         arr=[pos,num]
        object.push(arr)
        <?php 
    }
?>
    function initMap(center={ lat: 20.5937, lng: 78.9629 },zoom=8) {
    

  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: zoom,
    center: center,
  });
  for(var i=0;i<object.length;i++)
  {
    object[i][0]['lat']=parseInt(object[i][0]['lat'])
    object[i][0]['lng']=parseInt(object[i][0]['lng'])
    var marker = new google.maps.Marker({
        position: object[i][0],
        map,
        title: object[i][1],
    });
    
  }
}
$(document).ready(function() {
        $('select').select2();
    });

$(document).on('change','select',function(){
    var val=$(this).val();
    if(val=='all')
    {
        return false;
    }
    $.ajax({
        url:`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURI(val)}&key=<?php echo e(env('MAP_API')); ?>

            `,
        method:"POST",
        success:function(data){
            data=data['results'][0]['geometry']['location']
            initMap(data,zoom=8)
        }
    })
})
</script>
<!-- start webpushr code --> <script>(function(w,d, s, id) {if(typeof(w.webpushr)!=='undefined') return;w.webpushr=w.webpushr||function(){(w.webpushr.q=w.webpushr.q||[]).push(arguments)};var js, fjs = d.getElementsByTagName(s)[0];js = d.createElement(s); js.id = id;js.async=1;js.src = "https://cdn.webpushr.com/app.min.js";fjs.parentNode.appendChild(js);}(window,document, 'script', 'webpushr-jssdk'));webpushr('setup',{'key':'BD1RV_xlcqWuYKMRT4ARVIej9HeK3oowqHEyylkX6RnK40hShMBQv-Wj_CMjpA_B_XuRsNBVixv2mi3bqeJ0ka8' ,'integration':'popup' });</script><!-- end webpushr code -->
<script>
    function _webpushrScriptReady(){
    webpushr('fetch_id',function (sid) { 
      console.log(sid)
      var _token=$("input[name*='_token']").val();

        $.ajax({
            url:'<?php echo e(route('save_push_id')); ?>',
            method:"POST",
            data:{
                _token:_token,
                sid:sid
            },
            success:function(data)
            {
                console.log(data);
            }
             
        });
       
    });
}
</script>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('transport.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\vts\ideal\resources\views/transport/dashboard.blade.php ENDPATH**/ ?>