<footer class="footer">
	© 2018 - 2020 <b>Drixo</b> <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesdesign.</span>
</footer>
<?php /**PATH K:\vts\ideal\resources\views/master_admin/footer.blade.php ENDPATH**/ ?>