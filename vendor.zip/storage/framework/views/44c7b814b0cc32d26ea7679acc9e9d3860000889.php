
<?php $__env->startSection('title','Master Add Branch'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper ">

    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="float-right page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Drixo</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
                <h5 class="page-title">Dashboard</h5>
            </div>
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-7" style="margin: auto;">
                <div class="card m-b-30">
                	<div class="p-2 bg-primary text-white">
                        <h4 class="header-title">Add  Branch</h4>
                		
                	</div>
                    <div class="card-body">
                    	<form method="POST" action="<?php echo e(route('branch_update',$branch->id)); ?>">
                    		<?php echo csrf_field(); ?>
                    		<div class="form-group">
                    			<label>Branch Name</label>
                    			<input type="text" value="<?php echo e($branch->name); ?>" name="branch_name" class="form-control">
                                <?php $__errorArgs = ['branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                    		</div>
                    		<div class="form-group">
                                <label>State</label>
                    		    <select class="form-control" name="state" id="state" onchange="getDistrict()">
                                    <option value="">Select District</option>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($state->id==old('state') || $state->id==$branch->state): ?>
                                        <option selected="" value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->state); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                    
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                            </div>
                            <div class="form-group"  id="district_con">
                                <label>District</label>
                                <select class="form-control" id="district" name="district">
                                    <option value="">Select District</option>
                                   <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($dist->id==old('district') || $dist->id==$branch->district): ?>
                                        <option selected="" value="<?php echo e($dist->id); ?>"><?php echo e($dist->district); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($dist->id); ?>"><?php echo e($dist->district); ?></option>
                                        <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                    
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                            </div>
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="phone" value="<?php echo e($branch->phone); ?>" class="form-control">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <textarea class="form-control" name="address"><?php echo e($branch->location); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>User name</label>
                                <input type="text" name="username" value="<?php if(old('username')!=''): ?> <?php echo e(old('username')); ?> <?php else: ?> <?php echo e($login[0]->username); ?><?php endif; ?>" class="form-control">
                               <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                    
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <input type="submit" name="save" value="Save" class="btn btn-primary">
                    	</form>
                    </div>
                </div>
            </div> <!-- end col -->
        </div>
        <!-- end row -->


    </div><!-- container fluid -->

</div>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('select').select2();
    });
    function getDistrict()
    {
        var state=$("#state").val();
        var _token=$("input[name*='_token']").val();
        if(state=='')
        {
            $("#district_con").hide();
            $("#district").html('<option>Select District</option>');
            return false;
        }
        $.ajax({
            url:"<?php echo e(route('district')); ?>",
            method:"POST",
            data:{
                state:state,
                _token:_token
            },
            beforeSend:function(){
                //$("#status").show();
                //$("#preloader").show();
                alert()
            },
            success:function(data)
            {
            $("#district_con").show();

                $("#status").hide();
                $("#preloader").hide();
                $("#district").html(data)
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_admin.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/idealroadways/idealroadways/resources/views/master_admin/update_branch.blade.php ENDPATH**/ ?>