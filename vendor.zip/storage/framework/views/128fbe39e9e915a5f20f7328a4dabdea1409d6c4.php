
<?php $__env->startSection('title','Add Load'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper ">

    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="float-right page-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Ideal Roadways</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
                <h5 class="page-title">Dashboard</h5>
            </div>
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-md-7" style="margin: auto;">
                <div class="card m-b-30">
                	<div class="p-2 bg-primary text-white">
                        <h4 class="header-title">Load Booking</h4>
                		
                	</div>
                    <div class="card-body">
                    	<form method="POST" action="<?php echo e(route('save_booking')); ?>">
                    		<?php echo csrf_field(); ?>
                    		<div class="form-group">
                    			<label>Load Id</label>
                                <select class="form-control" name="load" id="load" >
                                    <option value="">Select Load Id</option>
                                    <?php $__currentLoopData = $loads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $load): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($load->id==old('load')): ?>
                                        <option selected="" value="<?php echo e($load->id); ?>"><?php echo e($load->id); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($load->id); ?>"><?php echo e($load->id); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                                <?php $__errorArgs = ['load'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                    		</div>
                            <div class="form-group">
                    			<label>truck Id</label>
                                <select class="form-control"  name="truck" id="truck" >
                                    <option value="">Select truck Id</option>
                                    <?php $__currentLoopData = $trucks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($truck->id==old('truck')): ?>
                                        <option selected="" value="<?php echo e($truck->id); ?>"><?php echo e($truck->truck_number); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($truck->id); ?>"><?php echo e($truck->truck_number); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                                <?php $__errorArgs = ['truck'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                    		</div>

                            <input type="submit" name="save" value="Save" class="btn btn-primary">
                    	</form>
                    </div>
                </div>
            </div> <!-- end col -->
        </div>
        <!-- end row -->


    </div><!-- container fluid -->

</div>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
 
<script type="text/javascript">
    $(document).ready(function() {
        $('select').select2();
    });
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_admin.templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\vts\ideal\resources\views/master_admin/add_booking.blade.php ENDPATH**/ ?>