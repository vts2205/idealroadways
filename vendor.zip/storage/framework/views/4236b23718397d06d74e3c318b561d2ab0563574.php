<footer class="footer">
	© <?php echo date('Y')?> <b>Ideal Roadways</b> <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> <a href="https://viswatechnologysolutions.com/">Viswa Technology Solutions.</a>.</span>
</footer>
<?php /**PATH /home/idealroadways/idealroadways/resources/views/master_admin/footer.blade.php ENDPATH**/ ?>